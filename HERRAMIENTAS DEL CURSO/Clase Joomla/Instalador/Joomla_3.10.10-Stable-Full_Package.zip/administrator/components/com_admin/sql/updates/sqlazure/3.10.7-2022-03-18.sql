ALTER TABLE [#__users] ADD [authProvider] [nvarchar](100) NOT NULL DEFAULT '';

﻿namespace GustoySazon.Controllers
{
    public interface IActionResult
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GustoySazon.Models
{
    public class ResumenPagoModel
    {
        public DateTime Fecha { get; set; }
        public decimal TotalPagado { get; set; }
    }
}
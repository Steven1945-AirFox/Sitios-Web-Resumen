﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GustoySazon.Models
{
    public class SimulacionModel
    {
        public int Id { get; set; }
        public DateTime FechaInicio { get; set; }
        public string Estado { get; set; }
    }
}
